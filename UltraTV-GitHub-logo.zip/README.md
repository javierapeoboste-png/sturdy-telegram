# UltraTV Android

App Android/WebView para:
- Android celular/tablet
- Android TV / Google TV

URL:
https://ultratvi.netlify.app/

## Generar APK
En Android Studio:
Build > Build APK(s)

## Generar AAB
Build > Generate Signed Bundle / APK > Android App Bundle

Para GitHub Actions, el workflow incluido genera un APK de debug automáticamente en cada push.

## Requisitos
- Android Studio reciente
- JDK 17
- Android SDK 36

## Logo
El proyecto incluye el logo Ultra TV proporcionado en la conversación como icono y splash inicial.
